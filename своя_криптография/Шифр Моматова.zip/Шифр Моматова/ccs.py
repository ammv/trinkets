class CCS:

    #АЛФАВИТЫ
    _RU = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    _EN = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    _NUMS = '0123456789'
    #_CLASSES = {'S': _S(), 'IS': CCS._IS(), 'D': CCS._D(), 'OS': CCS._OS(), 'OIS': CCS._OIS()}

    #ИНИЦИАЛИЗАЦИЯ КЛЮЧА КЛАССА СДВИГА
    #ПРОВЕРКА LCS НА ВАЛИДНОСТЬ
    #ПРОВЕРКА КЛАССА НА СУЩЕСТВОВАНИЕ
    @classmethod
    def key(self, column, _class, shift):
        column, _class, shift = str(column), str(_class), str(shift)
        CCS._check_lcs(column, _class, shift)
        _class = CCS._find_class(_class)
        return (CCS._table(column, shift, _class))

    #СОЗДАНИЕ ТАБЛИЦ
    def _table(column, shift, _class):
        column, shift = int(column), int(shift)
        #СОЗДАНИЕ АЛФАВИТА В ВИДЕ ТАБЛИЦЫ
        language = CCS._RU + '#' * column

        table = []
        for i in range(0, len(language), column):
            table.append(language[i:i+column])

        for i in table.copy():
            if i[0] == '#':
                table.remove(i)

        return dict((('table', table), ('language', CCS._RU), ('shift', shift), ('class', _class)))

    #ENCODE
    @classmethod
    def encode(self, text, args):
        if args['class'] == 'S':
            f = CCS._S(text, args)
        elif args['class'] == 'IS':
            f = CCS._IS(text, args)
        elif args['class'] == 'D':
            f = CCS._D(text, args)
        elif args['class'] == 'OS':
            f = CCS._OS(text, args)
        elif args['class'] == 'OIS':
            f = CCS._OIS(text, args)
        return f


    #STANDART
    def _S(text, args):
        shift = args['shift']
        table = args['table']
        table_low = [row.lower() for row in table]
        lang = args['language']+args['language']
        lang_low = lang.lower()

        max_rows = len(table)
        encoded_text = ''
        for letter in text:

            print('БУКВА ИЗ TEXT:', letter)
            #UPPER
            if letter in lang:
                for row in table:
                    if letter in row:
                        i_row = table.index(row)
                        i_letter = row.index(letter)
                        if i_row != max_rows-1:
                            print('ОПУСКАЕМ БУКВУ')
                            if i_row + 1 <= max_rows - 1:
                                if table[i_row+1][i_letter] == '#':
                                    pass
                                else:
                                    i_letter = lang.index(table[i_row+1][i_letter])
                                    new_letter = lang[i_letter+shift]
                                    print('ОПУСТИЛИ БУКВУ(index) ->:', i_letter+1)
                                    print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang.index(table[i_row][i_letter])
                                new_letter = lang[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)

                        elif i_row == max_rows-1:
                            print('ПОДНИМАЕМ БУКВУ')
                            if i_row - 1 < max_rows-1:
                                i_letter = lang.index(table[i_row-1][i_letter])
                                new_letter = lang[i_letter+shift]
                            else:
                                i_letter = lang.index(table[i_row][i_letter])
                                new_letter = lang[i_letter+shift]

            #LOWER
            elif letter in lang_low:
                for row in table_low:
                    if letter in row:
                        i_row = table_low.index(row)
                        i_letter = row.index(letter)
                        if i_row != max_rows-1:
                            print('ОПУСКАЕМ БУКВУ')
                            if i_row + 1 <= max_rows - 1:
                                if table_low[i_row+1][i_letter] == '#':
                                    pass
                                else:
                                    i_letter = lang_low.index(table_low[i_row+1][i_letter])
                                    new_letter = lang_low[i_letter+shift]
                                    print('ОПУСТИЛИ БУКВУ(index) ->:', i_letter+1)
                                    print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang_low.index(table_low[i_row][i_letter])
                                new_letter = lang_low[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)

                        elif i_row == max_rows-1:
                            print('ПОДНИМАЕМ БУКВУ')
                            if i_row - 1 < max_rows-1:
                                i_letter = lang_low.index(table_low[i_row-1][i_letter])
                                new_letter = lang_low[i_letter+shift]
                            else:
                                i_letter = lang_low.index(table_low[i_row][i_letter])
                                new_letter = lang_low[i_letter+shift]
            else:
                new_letter = letter

            encoded_text += new_letter

        return encoded_text

    #INVERSION STANDART
    def _IS(text, args):
        shift = args['shift']
        table = args['table']
        table_low = [row.lower() for row in table]
        lang = args['language']+args['language']
        lang_low = lang.lower()

        max_rows = len(table)
        encoded_text = ''
        for letter in text:

            print('БУКВА ИЗ TEXT:', letter)
            #UPPER
            if letter in lang:
                for row in table:
                    if letter in row:
                        i_row = table.index(row)
                        i_letter = row.index(letter)
                        if max_rows > 2:
                            if i_row != 0 and i_row != max_rows-1:
                                i_letter = lang.index(table[i_row-1][i_letter])
                                new_letter = lang[i_letter+shift]
                                print('ПОДНЯЛИ БУКВУ(index) ->:', i_letter+1)
                                print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang.index(table[i_row][i_letter])
                                new_letter = lang[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
                        else:
                            i_letter = lang.index(table[i_row][i_letter])
                            new_letter = lang[i_letter+shift]
                            print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)

            #LOWER
            elif letter in lang_low:
                for row in table_low:
                    if letter in row:
                        i_row = table_low.index(row)
                        i_letter = row.index(letter)
                        if max_rows > 2:
                            if i_row != 0 and i_row != max_rows-1:
                                i_letter = lang_low.index(table_low[i_row-1][i_letter])
                                new_letter = lang_low[i_letter+shift]
                                print('ПОДНЯЛИ БУКВУ(index) ->:', i_letter+1)
                                print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang_low.index(table_low[i_row][i_letter])
                                new_letter = lang_low[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
                        else:
                            i_letter = lang_low.index(table_low[i_row][i_letter])
                            new_letter = lang_low[i_letter+shift]
                            print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
            else:
                new_letter = letter

            encoded_text += new_letter

        return encoded_text

    #DOWN
    def _D(text, args):
        shift = args['shift']
        table = args['table']
        table_low = [row.lower() for row in table]
        lang = args['language']+args['language']
        lang_low = lang.lower()

        max_rows = len(table)
        encoded_text = ''
        for letter in text:

            print('БУКВА ИЗ TEXT:', letter)
            #UPPER
            if letter in lang:
                for row in table:
                    if letter in row:
                        i_row = table.index(row)
                        i_letter = row.index(letter)
                        if max_rows > 1:
                            if i_row != max_rows - 1:
                                i_letter = lang.index(table[i_row+1][i_letter])
                                new_letter = lang[i_letter+shift]
                                print('ОПУСТИЛИ БУКВУ(index) ->:', i_letter+1)
                                print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang.index(table[i_row][i_letter])
                                new_letter = lang[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
                        else:
                            i_letter = lang.index(table[i_row][i_letter])
                            new_letter = lang[i_letter+shift]
                            print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)

            #LOWER
            elif letter in lang_low:
                for row in table_low:
                    if letter in row:
                        i_row = table_low.index(row)
                        i_letter = row.index(letter)
                        if max_rows > 1:
                            if i_row != max_rows - 1:
                                i_letter = lang_low.index(table_low[i_row+1][i_letter])
                                new_letter = lang_low[i_letter+shift]
                                print('ОПУСТИЛИ БУКВУ(index) ->:', i_letter+1)
                                print('СДЕЛАЛИ СДВИГ ->:', new_letter)
                            else:
                                i_letter = lang_low.index(table_low[i_row][i_letter])
                                new_letter = lang_low[i_letter+shift]
                                print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
                        else:
                            i_letter = lang_low.index(table_low[i_row][i_letter])
                            new_letter = lang_low[i_letter+shift]
                            print('СДЕЛАЛИ ТОЛЬКО СДВИГ ->:', new_letter)
            else:
                new_letter = letter

            encoded_text += new_letter

        return encoded_text

    #ONLY SHIFT
    def _OS(text, args):
        pass

    #ONLY INVERSION SHIFT
    def _OIS(text, args):
        pass

    #ПОИСК КЛАССА ИЛИ ПРОВЕРКА НА ВАЛИДНОСТЬ
    def _find_class(_class):
        CLASSES = ['S', 'IS', 'D', 'OS', 'OIS']

        if _class in CLASSES:
            return _class
        else:
            print('This class not exist')
            exit()

    #ПРОВЕРКА ДАННЫХ НА ВАЛИДНОСТЬ
    def _check_lcs(column, _class, shift):
        #invalid line
        if column.isdigit():
            if int(column) < 1:
                print('Column must be then more 0')
                exit()
        elif column.isalpha():
            print('Line must be a number')
            exit()

        #invalid class
        if _class.isalpha():
            pass
        elif _class.isdigit():
            print('Class must be alpha')
            exit()

        #invalid shift
        if shift.isdigit():
            pass
        elif column.isalpha():
            print('Shift must be a number')
            exit()
