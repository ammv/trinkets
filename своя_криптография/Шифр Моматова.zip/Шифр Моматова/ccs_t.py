from ccs import CCS as cs

#ТАБЛИЦА ПОКА ТОЛЬКО ДЛЯ РУССКОГО ЯЗЫКА
#ВПРОЧЕМ РЕАЛИЗАЦИЯ ЭТОГО ШИФРА ПРОСТО ПРАКТИКА В КРИПТОГРАФИИ(нет)) )
key = cs.key(11, 'D', 2)
encoded_text= cs.encode('Никитос привет', key)
print(encoded_text)

